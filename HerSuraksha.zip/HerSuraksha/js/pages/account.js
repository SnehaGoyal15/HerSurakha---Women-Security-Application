import { getCurrentUser, isLoggedIn, logout } from "../firebase/auth.js";
import { getFirestore, doc, getDoc, updateDoc, deleteDoc } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { getAuth, deleteUser } from "firebase/auth";

// Check if user is logged in
if (!isLoggedIn()) {
    window.location.href = 'login.html';
}

// Get user data
const user = getCurrentUser();
const db = getFirestore();
const storage = getStorage();
const auth = getAuth();

// Update greeting with user's first name
const greetingEl = document.getElementById('greetingMessage');
if (greetingEl && user) {
    const firstName = user.name ? user.name.split(' ')[0] : 'User';
    greetingEl.innerHTML = `Hi ${firstName}`;
}

// Load user data from Firestore
async function loadUserData() {
    if (!user || !user.userId) return;
    
    try {
        const userDoc = await getDoc(doc(db, "users", user.userId));
        if (userDoc.exists()) {
            const data = userDoc.data();
            
            // Update display fields
            document.getElementById('displayName').textContent = data.name || 'Not set';
            document.getElementById('displayMobile').textContent = data.mobile || 'Not set';
            document.getElementById('displayEmail').textContent = data.email || 'Not set';
            document.getElementById('displayBlood').textContent = data.blood || 'Not set';
            document.getElementById('displayAddress').textContent = data.address || 'Not added yet';
            
            // Set edit form values
            document.getElementById('editName').value = data.name || '';
            document.getElementById('editMobile').value = data.mobile || '';
            document.getElementById('editEmail').value = data.email || '';
            document.getElementById('editBlood').value = data.blood || '';
            document.getElementById('editAddress').value = data.address || '';
            
            // Load fake call settings from localStorage
            const fakeCallName = localStorage.getItem('fakeCallName') || 'Mom';
            const fakeCallNumber = localStorage.getItem('fakeCallNumber') || '1234567890';
            const fakeCallRingtone = localStorage.getItem('fakeCallRingtone') || 'default';
            
            document.getElementById('fakeCallName').value = fakeCallName;
            document.getElementById('fakeCallNumber').value = fakeCallNumber;
            document.getElementById('fakeCallRingtone').value = fakeCallRingtone;
        }
    } catch (error) {
        console.error("Error loading user data:", error);
    }
}

// Initial load
loadUserData();

// Profile photo upload
const profileAvatar = document.getElementById('profileAvatar');
const photoUpload = document.getElementById('photoUpload');
const avatarImg = document.getElementById('avatarImg');

profileAvatar.addEventListener('click', () => {
    photoUpload.click();
});

photoUpload.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
        // Show loading state
        avatarImg.style.opacity = '0.5';
        
        // Upload to Firebase Storage
        const storageRef = ref(storage, `profile_photos/${user.userId}`);
        await uploadBytes(storageRef, file);
        const photoURL = await getDownloadURL(storageRef);
        
        // Update Firestore
        await updateDoc(doc(db, "users", user.userId), {
            photoURL: photoURL
        });
        
        // Update UI
        avatarImg.src = photoURL;
        avatarImg.style.opacity = '1';
        
        alert('Profile photo updated successfully!');
    } catch (error) {
        console.error("Error uploading photo:", error);
        alert('Failed to upload photo');
        avatarImg.style.opacity = '1';
    }
});

// Edit profile button
document.getElementById('editProfileBtn').addEventListener('click', () => {
    document.getElementById('viewMode').style.display = 'none';
    document.getElementById('editMode').style.display = 'block';
});

// Cancel edit button
document.getElementById('cancelEditBtn').addEventListener('click', () => {
    document.getElementById('viewMode').style.display = 'block';
    document.getElementById('editMode').style.display = 'none';
});

// Save profile changes
document.getElementById('saveProfileBtn').addEventListener('click', async () => {
    if (!user || !user.userId) return;
    
    const updatedData = {
        name: document.getElementById('editName').value,
        mobile: document.getElementById('editMobile').value,
        email: document.getElementById('editEmail').value,
        blood: document.getElementById('editBlood').value,
        address: document.getElementById('editAddress').value
    };
    
    try {
        await updateDoc(doc(db, "users", user.userId), updatedData);
        
        // Update localStorage
        const updatedUser = { ...user, ...updatedData };
        localStorage.setItem('currentUser', JSON.stringify(updatedUser));
        
        // Update display
        document.getElementById('displayName').textContent = updatedData.name;
        document.getElementById('displayMobile').textContent = updatedData.mobile;
        document.getElementById('displayEmail').textContent = updatedData.email;
        document.getElementById('displayBlood').textContent = updatedData.blood;
        document.getElementById('displayAddress').textContent = updatedData.address || 'Not added yet';
        
        // Switch back to view mode
        document.getElementById('viewMode').style.display = 'block';
        document.getElementById('editMode').style.display = 'none';
        
        alert('Profile updated successfully!');
    } catch (error) {
        console.error("Error updating profile:", error);
        alert('Failed to update profile');
    }
});

// Save fake call settings
document.getElementById('saveFakeCallSettings').addEventListener('click', () => {
    const fakeCallName = document.getElementById('fakeCallName').value;
    const fakeCallNumber = document.getElementById('fakeCallNumber').value;
    const fakeCallRingtone = document.getElementById('fakeCallRingtone').value;
    
    localStorage.setItem('fakeCallName', fakeCallName);
    localStorage.setItem('fakeCallNumber', fakeCallNumber);
    localStorage.setItem('fakeCallRingtone', fakeCallRingtone);
    
    alert('Fake call settings saved!');
});

// Logout button
document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
        logout();
    }
});

// Delete account button
document.getElementById('deleteAccountBtn').addEventListener('click', async () => {
    if (!confirm('Are you sure you want to delete your account? This action cannot be undone!')) {
        return;
    }
    
    if (!confirm('This will permanently delete all your data. Type "DELETE" to confirm.')) {
        return;
    }
    
    try {
        // Delete user data from Firestore
        await deleteDoc(doc(db, "users", user.userId));
        
        // Delete all contacts
        // (Add code to delete contacts collection)
        
        // Delete user authentication
        const currentUser = auth.currentUser;
        if (currentUser) {
            await deleteUser(currentUser);
        }
        
        // Clear localStorage
        localStorage.clear();
        
        alert('Account deleted successfully');
        window.location.href = 'login.html';
    } catch (error) {
        console.error("Error deleting account:", error);
        alert('Failed to delete account. Please try again.');
    }
});

// Footer Navigation
document.getElementById('homeBtn').addEventListener('click', () => {
    window.location.href = 'dashboard.html';
});

document.getElementById('contactsBtn').addEventListener('click', () => {
    window.location.href = 'contacts.html';
});

document.getElementById('addBtn').addEventListener('click', () => {
    window.location.href = 'add-contact.html';
});

document.getElementById('locationBtn').addEventListener('click', () => {
    window.location.href = 'dashboard.html#location';
});

document.getElementById('accountBtn').addEventListener('click', () => {
    window.location.href = 'account.html';
});

// Help button
document.getElementById('helpBtn').addEventListener('click', () => {
    window.location.href = 'help.html';
});

// Active state for footer icons
document.querySelectorAll('.icon-box').forEach(icon => {
    icon.addEventListener('click', function() {
        document.querySelectorAll('.icon-box').forEach(i => i.classList.remove('active'));
        this.classList.add('active');
    });
});