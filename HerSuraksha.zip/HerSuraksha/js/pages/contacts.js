import { getContacts } from "../firebase/firestore.js";
import { getCurrentUser, isLoggedIn } from "../firebase/auth.js";

// Redirect if not logged in
if (!isLoggedIn()) {
    window.location.href = 'login.html';
}

const user = getCurrentUser();

// Display personalized message in header
const welcomeEl = document.getElementById('welcomeMessage');
if (welcomeEl && user) {
    const firstName = user.name.split(' ')[0];
    welcomeEl.innerHTML = `Hi ${firstName}, your emergency contacts`;
}

// Load and display contacts
async function loadContacts() {
    const contactsList = document.getElementById('contactsList');
    
    if (!user) return;
    
    const contacts = await getContacts(user.userId);
    
    if (contacts.length === 0) {
        contactsList.innerHTML = `
            <div class="no-contacts">
                <p>📭 No emergency contacts added yet</p>
                <p style="font-size:16px; margin-top:15px;">Click "Add New Contact" to add one</p>
            </div>
        `;
        return;
    }
    
    contactsList.innerHTML = contacts.map(contact => `
        <div class="contact-card" data-id="${contact.id}">
            <div class="contact-info">
                <div class="contact-name">${contact.name}</div>
                <div class="contact-details">
                    <div class="contact-phone">
                        <svg width="18" height="18" viewBox="0 0 24 24">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" fill="#666"/>
                        </svg>
                        ${contact.phone}
                    </div>
                    ${contact.relation ? `<span class="contact-relation">${contact.relation}</span>` : ''}
                </div>
            </div>
            <div class="action-buttons">
                <!-- CALL BUTTON -->
                <button class="action-btn call-btn" onclick="window.location.href='tel:${contact.phone}'">
                    <svg width="22" height="22" viewBox="0 0 24 24">
                        <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" fill="white"/>
                    </svg>
                </button>
                
                <!-- MESSAGE BUTTON (SMS) -->
                <button class="action-btn msg-btn" onclick="window.location.href='sms:${contact.phone}'">
                    <svg width="22" height="22" viewBox="0 0 24 24">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2z" fill="white"/>
                    </svg>
                </button>
            </div>
        </div>
    `).join('');
}

// Initial load
loadContacts();

// Navigation
document.getElementById('addNewContact').addEventListener('click', () => {
    window.location.href = 'add-contact.html';
});

// Footer Navigation
document.getElementById('homeBtn').addEventListener('click', () => {
    window.location.href = 'dashboard.html';
});

document.getElementById('contactsBtn').addEventListener('click', () => {
    window.location.href = 'contacts.html';
});

document.getElementById('addBtn').addEventListener('click', () => {
    window.location.href = 'add-contact.html';
});

document.getElementById('locationBtn').addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const { latitude, longitude } = position.coords;
            window.open(`https://www.google.com/maps?q=${latitude},${longitude}`);
        });
    }
});

document.getElementById('accountBtn').addEventListener('click', () => {
    if (confirm("Do you want to logout?")) {
        localStorage.clear();
        window.location.href = "login.html";
    }
});

// Active state for footer icons
document.querySelectorAll('.icon-box').forEach(icon => {
    icon.addEventListener('click', function() {
        document.querySelectorAll('.icon-box').forEach(i => i.classList.remove('active'));
        this.classList.add('active');
    });
});